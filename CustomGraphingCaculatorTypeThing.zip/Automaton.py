import matplotlib.pyplot as plt
from Global import functions
from copy import deepcopy

class Automaton():
  def __init__(self, boundFunction):
    functions.append(boundFunction)
    self.func = boundFunction

  def forceVariables(self, parameters, variables, domain1, domain2, increment):
    self.variables = []
    for i in range(len(parameters)):
      self.variables.append([parameters[i], variables[i]])
    #print(self.variables)
    self.start = domain1
    self.end = domain2
    self.add = increment

  def friendlyCreate(self, parameters):
    self.variables = []
    for i in range(len(parameters)):
      self.variables.append([parameters[i], input("Enter Value of Parameter " + parameters[i] + " or 'X' to Have it be Equal to the value of X: ")])
    self.start = float(input("Enter start of x range: "))
    self.end = float(input("Enter end of x range: "))
    self.add = float(input("Enter increment: "))

  def call(self, xval):
    print("\033[38;5;82m" + str(xval) + "\033[38;5;15m")
    cpy = deepcopy(self.variables)
    #print(cpy)
    for i in range(len(cpy)):
      if cpy[i][1] == "X": cpy[i][1] = xval
    #print(cpy)
    val = self.func.Execute(cpy)
    #print(xval, val)
    return val

  def graph(self):
    x = []
    y = []

    num = self.start
    while num <= self.end:
      x.append(num)
      y.append(self.call(num))
      num+=self.add

    print("\033[38;5;55mDONE CACULATING")
    print("\033[38;5;226m")
    arr = [226, 227, 228, 229, 118, 119, 120, 121, 123, 15, 51, 87]
    counter = 0
    for i in range(len(x)): 
      print("\033[38;5;" + str(arr[counter % 12]) + "m", end="")
      #print(str(arr[counter % 13]))
      counter+=1
      print(x[i], y[i], end = "  ", sep="->")
    plt.plot(x, y)
    plt.xlabel("x-axis")
    plt.ylabel("y-axis")
    plt.title(self.func.remember)
    print("Showing...")
    plt.show()


