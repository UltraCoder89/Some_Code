functions = []

def printColors():
  for i in range(256): print("\033[38;5;" + str(i) + "m", i, sep="", end="  ") #I just like the colors