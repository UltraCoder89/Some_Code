from FunctionEater import Function
from Automaton import Automaton
def engage():
  i = ""
  while True:
    try:
      print("Intput The Highest X Value You Would Like To Check: ", end="")
      i = int(input())
    except:
      print("Enter An Integer!")
      continue
    break

  f = Automaton(Function("f(a,b)={sqrt(a)<b:1 , a%b=0:0 , f(a,b+1)}"))

  f.forceVariables(["a", "b"], ["X",2], 0, i, 1)
  f.graph()