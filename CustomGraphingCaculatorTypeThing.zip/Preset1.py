from FunctionEater import Function
from Automaton import Automaton
def engage():
  f = Automaton(Function("f(x)={x<=2:1 , f(x-1)+f(x-2)}"))
  f.forceVariables(["x"], ["X"], 0, 15, 1)
  f.graph()