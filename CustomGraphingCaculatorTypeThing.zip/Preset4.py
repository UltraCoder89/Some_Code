from FunctionEater import Function
from Automaton import Automaton
def engage():
  f = Automaton(Function("f(x)={(x)**2}"))
  f.forceVariables(["x"], ["X"], -100, 100, 1)
  f.graph()