print("importing modules, this might take a minute")
from Global import functions
from sys import setrecursionlimit
from FunctionEater import Function
from Automaton import Automaton

setrecursionlimit(10 ** 8)
print("Recursive Limit ", 10 ** 8)
option = 0

while True:
  try:
    option += int(input("Please Select Mode:\n[1]Default Preset\n[2]Enter Own Function\nEnter Number Then Press The Return Key:\t"))
    if option == 1 or option == 2:
      break
  except:
    pass
  print("Enter 1 or 2")
  option *= 0
  
if option == 2:
  print("\033[38;5;196m" + "\nNOTE: it is assumed that the user will provide correct input\033[38;5;51m\n")

  print("\033[38;5;51m", end="")

  print("Note that spaces should be used when seperating if else statements on top of commas for instance \033[38;5;90mf(x)={x<=2:1,f(x-1)+f(x-2)} \033[38;5;51mShould instead be \033[38;5;88mf(x)={x<=2:1 , f(x-1)+f(x-2)}\033[38;5;51m\n")

  for i in range(int(input("Enter Number Of Functions:"))):
    equation = input("Function " + str(i) + ":\t")
    functions.append(Function(equation))
  print("Select Function To Graph (it will be able to use other functions)")
  for i in range(len(functions)):
    print("[" + str(i) + "]", functions[i].functionName)
  i = int(input("Enter Anwer Here: "))
  auto = Automaton(functions[i])
  auto.friendlyCreate(functions[i].vars)
  auto.graph()

else:
  try:
    val = int(input("1 (fibonacci), 2 (prime number finder), 3 (nbonnaci), 4 (parabola): "))
  except:
    print("Invalid Input. Defaulting to 1")
    val = 1
  if int(val) == 1:
    from Preset1 import engage
  elif int(val) == 2:
    from Preset2 import engage
  elif int(val) == 3:
    from Preset3 import engage
  elif int(val) == 5:
    from Preset5 import engage
  else:
    from Preset4 import engage
  engage()