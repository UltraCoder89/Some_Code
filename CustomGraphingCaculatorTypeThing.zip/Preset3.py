from FunctionEater import Function
from Automaton import Automaton
from Global import functions

def engage():
  i = ""
  while True:
    try:
      print("Intput The Amount Of Prior Terms To Add: ", end="")
      i = int(input())
    except:
      print("Enter An Integer!")
      continue
    if i < 1:
      print("Input Less Than 1!")
      continue
    break
  e = ""
  while True:
    try:
      print("Intput The Maximum Position: ", end="")
      e = int(input())
    except:
      print("Enter An Integer!")
      continue
    if e < 1:
      print("Input Less Than 1!")
      continue
    break
  auto = Automaton(Function("a(t,p) = {t=p:1 , p<t:0 , c(t,p,1)}"))

  functions.append(Function("c(t,p,o) = {t<o:0 , c(t,p,o+1)+a(t,p-o)}"))

  auto.forceVariables(["t","p"], [i, "X"], 0, e, 1)
  auto.graph()