from FunctionEater import Function
from Automaton import Automaton
from random import random

def equation(point1, point2):
  x1, y1, x2, y2 = float(eval(point1[:point1.find(",")])), float(eval(point1[point1.find(",") + 1:])), float(eval(point2[:point2.find(",")])), float(eval(point2[point2.find(",") + 1:]))
  try:
    slope = (y1 - y2)/(x1 - x2)
  except:
    slope = 10
  return str(round(slope, 3)) + " * x + " + str(y1 - (x1 * slope))
def engage():
  print("\033[38;5;196m" + "\nNOTE: it is assumed that the user will provide correct input\033[38;5;51m\n")
  lower=int(input("lower:"))
  upper=int(input("upper:"))
  desmosF = input("Enter 1 followed by enter to have the function be in desmos format: ") == "1"
  amt = int(input("Amount of Functions"))
  olower = lower 
  oupper = upper
  assert lower < upper
  for i in range(amt):
    lower = olower 
    upper = oupper
    avgLen = 11
    function="f(x)=\left\{" if desmosF else "f(x)={ "
    formerPointX = lower 
    formerPointY = int(random() * 100)
    while lower < upper:
      randIncrement = 0
      while randIncrement == 0:
        randIncrement = int(random() * 2 * avgLen)
      if lower + randIncrement > upper:
        randIncrement = upper-lower
      oldLower = lower
      lower += randIncrement 
      newPoint2X = lower
      newPoint2Y = int(random() * 1000) - int(random() * 1000)
      function += str(oldLower) + (("\\le x \\le ") if desmosF else ("<=x" + " and x<=")) + str(lower) + ":" + equation(str(formerPointX) + "," + str(formerPointY), str(newPoint2X) + "," + str(newPoint2Y))
      if lower < upper:
        function += " , "  
      formerPointX *= 0
      formerPointX += newPoint2X
      formerPointY *= 0
      formerPointY += newPoint2Y
    function+= "\\right\\}" if desmosF else " }"
    print(function)