from Global import functions
from math import * #important

def getFunctionByName(name):
  for i in functions:
    if i.functionName == name:
      return i

def sort2d(ls):
  #print(ls)
  return sorted(ls, key=lambda x:len(x[0]), reverse=True)
  

# variables = [[name, value]]
def breakdown(thing, variables):
  #print(variables)
  variables = sort2d(variables)
  #print(variables)
  names = [i.functionName for i in functions]
  names = sorted(names, key=len, reverse=True)

  for i in names:
    while i + "(" in thing:
      open = 1
      alteredThing = ""
      disectingString = thing[thing.find(i + "(") + len(i + "("):]
      
      while open != 0:
        if disectingString[0] == "(":
          open += 1
        elif disectingString[0] == ")":
          open -= 1
        if open == 0:
          break
        else:
          alteredThing += disectingString[0]
          disectingString = disectingString[1:]
      #print(alteredThing, "ALT", i, "NAME")

      #print(thing)

      #print(thing[:thing.find(i + "(")], thing[thing.find(alteredThing) + len(alteredThing)+1:], sep="\t")

      thing = thing[:thing.find(i + "(")] + str(getFunctionByName(i).evaluate(alteredThing, variables)) + thing[thing.find(alteredThing) + len(alteredThing)+1:]

      #print(alteredThing)
      #exit(0)

  for name,value in variables:
    #print(name, value, "HERE")
    thing = thing.replace(str(name), str(value))
  #print(thing)
  #print(variables)
  #print(thing)
  return eval(thing)

def process(statement, variables):
  #print("HERE")
  return breakdown(statement, variables)

class Function():
  def __init__(self, func):
    self.remember = func
    sfunc = func
    func = func.replace(" ", "")
    #Variable creation
    #Vars
    openingVarDef = func.find('(')
    closingVarDef = func.find(')')
    innerDef = func[openingVarDef + 1: closingVarDef]

    self.functionName = func[:openingVarDef] #Get function name
    self.varAmt = innerDef.count(",") #Get amount of variables
    self.vars = innerDef.split(",") #Create list of variables

    #Logic creation
    #Vars 
    openCurly = sfunc.find('{') + 1
    closeCurly = sfunc.find('}')
    innerCurly = sfunc[openCurly:closeCurly].replace("=", "==").replace(">==", ">=").replace("<==", "<=").replace("^", "**") #converts to python readable format without the amount of exta logic I thought I would need >:)
    everything = innerCurly.split(' , ')

    #print(everything)

    logicalOperandums = []
    statements = []
    default = None
    defaultCount = 0

    #initalize arrays of logical operandums and statements
    for i in everything:
      if not ':' in i:
        #print(i, default)
        assert default == None
        default = i
        defaultCount += 1
      else:
        logicalOperandums.append(i[:i.find(":")])
        statements.append(i[i.find(":") + 1:])
    self.default = default
    self.logicOp = logicalOperandums
    self.statements = statements
    #print(logicalOperandums, statements)
    #exit(0)
  """
  def createFinalVars(self):
    self.VARIABLES = {}
    self.Graph = False
    for i in self.vars:
      if i == "x":
        self.VARIABLES[i] = "SPCAL"
        self.Graph = True
      else:
        self.VARIABLES[i] = input("What would you like variable " + i + " to be? For it to be the x value in a graph type \'SPCAL\' this is done automatically to variables called x\t")
        if self.VARIABLES[i] == "SPCAL":
          self.Graph = True
        else:
          self.VARIABLES[i] = int(self.VARIABLES[i])
    print("Final Variable Creation Done! Procedding to Computacion")
    self.limit = input("Please Enter A Recurive Limit (10^x where x is your input): ")
    setrecursionlimit(10 ** self.limit)
  
  def evaluate(self, vars, values, stmt):
    for i in functions:
      pos = stmt.find(i.functionName + "(")
      if pos != -1:
        astmt = stmt[pos+len(i.functionName)+1:]
        nstmt = ""
        open = 1
        for e in astmt:
          if e == '(':
            open+=1
          elif e == ')':
            open-=1
          if open == 0:
            stmt = stmt[:pos] + i.process(nstmt.split(","))
          else:
            nstmt += e


  def process(self, values):
    dictVals = {}
    valNames = []

    for i,e in self.vars,values:
      valNames.append(i)
      dictVals[i] = e

    #Don't question this I'm paranoid about worse cases
    vars = sorted(valNames, key=len, reverse=True)

    for r in len(self.logicOp):
      i = self.logicOp[r]
      for e in vars:
        i.replace(e, values[e])
  """


  def evaluate(self, parameters, variables):
    #First thing send stuff off to breakdown to make sure it is the most simplified setting next go through conds sending each one to breakdown and then send the first correct statement to process
    #print(parameters)
    simpleParameters = parameters.split(',')
    #print(variables)
    for i in range(len(simpleParameters)):
      simpleParameters[i] = breakdown(simpleParameters[i], variables)

    newVariables = []

    for i in range(len(simpleParameters)):
      newVariables.append([self.vars[i], simpleParameters[i]])
  
    #print(simpleParameters, self.vars, variables, sep="\t")
    #print(newVariables, " New Variables")
    for i in range(len(self.logicOp)):
      if breakdown(self.logicOp[i], newVariables):
        return process(self.statements[i], newVariables)
    return process(self.default, newVariables)
    return -1 # Error

  def Execute(self, variables):
    parameterNames = [i[0] for i in variables]
    return self.evaluate(str(parameterNames)[1:-1], variables)


      
        
          

      
    

#func: f(x, y) = {a > b:x,}