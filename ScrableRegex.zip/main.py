#!/usr/bin/env python
def scrableRegex(line, *args, useall=False, ignore_white_space=True, verbose=False, filename=False, infiniteTiles=False, fileVerbose=False):
    'returns true if the argument line can be made using characters in arg or a character from a collections of chars. useall: all args must be used, ignorewhitespace: ignore whitespace'

    if infiniteTiles and useall:
        return False

    if line: line = line.lower()

    if filename:
        f = open(filename).read()
        lines = f.split("\n")
        if verbose: print(lines)
        if fileVerbose: print(list(filter(lambda s: scrableRegex(s, *args, fileVerbose=fileVerbose, useall=useall, ignore_white_space=ignore_white_space, verbose=verbose, infiniteTiles=infiniteTiles), lines[:1000 if len(lines) > 1000 else len(lines)//10])))
        if len(lines) > 100000 and (fileVerbose or verbose):
            print("This may take a second")
        return list(filter(lambda s: scrableRegex(s, *args, fileVerbose=fileVerbose, useall=useall, ignore_white_space=ignore_white_space, verbose=verbose, infiniteTiles=infiniteTiles), lines))

    if ignore_white_space:
        from re import sub
        line = sub(r'\s', '', line)

    bracketPattern = []
    parenPattern = []
    
    for i in args:
        if len(i) > 1:
            parenPattern.append(i.lower())
        else:
            bracketPattern.append(i.lower())
    
    replaceMax = len(line) if infiniteTiles else 1

    preservedLine = line

    oldLine = line
    for i in bracketPattern:
        line = line.replace(i, "", replaceMax)
    
    if verbose: print(line)

    if useall and len(oldLine) - len(bracketPattern) != len(line):
        return False
    
    oldLine = line
    
    if useall and len(oldLine) - len(parenPattern) != 0:
        return False

    arr = [0 for i in range(len(parenPattern))]

    if (not arr) or (not line): 
        return not line
    
    
    if not infiniteTiles:
        while line:
            line = oldLine
            for element,index in zip(parenPattern, arr):
                if verbose: print(f"{arr=} {line=} {index=} {parenPattern=}")
                line = line.replace(element[index], "", 1)
            if verbose: print(line)
            if not line:
                break
            else:
                arr[0] += 1
                for index in range(len(arr)):
                    try:
                        if arr[index] >= len(parenPattern[index]):
                            if verbose: print(f"{arr=} {line=} {index=} {parenPattern=}")
                            arr[index] = 0
                            arr[index + 1] += 1
                    except IndexError:
                        return False

        return True
    else:
        for num1,ele in enumerate(parenPattern):
            for num2,oele in enumerate(parenPattern[num1 + 1:]):
                for char1 in ele:
                    for char2 in oele:
                        if char1 == char2:
                            line.replace(char1)
                            parenPattern[num1] = parenPattern[num1].replace(char1, "")
                            parenPattern[num2] = parenPattern[num2].replace(char1, "")
        
        from re import search,sub
        for i in parenPattern:
            ptrn = "[" + i + "]" + "{2}"
            if search(ptrn, line):
                return False
            line = sub("[" + i + "]", "", line)
            
        if not line:
            #if fileVerbose: print(preservedLine)
            return True
        #allows infinite use of multi tile collections ie 'abc' if not successive ie 'aa' is not allowed

class Node:
    def __init__(self, data):
        self.data = data
        self.nexts = []
    def populateData(self, wds, chars, depth=0, verbose=False):
        if depth >= 3:
            return None
        else:
            for i in self.data:
                chars = chars.replace(i, "")
            for i in wds:
                try:
                    if i and self.data and i[0] == self.data[-1]:
                        if verbose:
                          print(i, self.data)
                        self.nexts.append(Node(i).populateData(wds, chars, depth + 1))
                except:
                    print(f"{wds=} {chars=} {i=} {self.data=}")
                    exit()
    def findShortestPaths(self, depth=0, verbose=False):
        if len(self.nexts) == 0:
            return depth
        else:
            lst = [] # (depth, words)
            for i in self.wds:
                lst.append(i.findShortestPaths(depth + 1))
            smallest = 10 ** 10 
            smallestWd = None
            for debth,wd in lst:
                if debth < smallest:
                    if verbose:
                      print(smallest, wd)
                    smallestWd = wd
                    smallest = debth
            return (debth, self.data + "-" + smallestWd)

def letterBoxed(*sides, verbose=False):
    chars = ""
    for i in sides:
        chars += i
    validWds=['a', 'ae', 'AEA', 'AEF', 'aemia', 'aer', 'aery', 'aero', 'AF', 'AFA', 'AFAM', 'AFL', 'aflame', 'AFM', 'afoam', 'AFP', 'AI', 'AIA', 'Aiea', 'ail', 'Aila', 'AIM', 'aimara', 'AIME', 'aimer', 'Aimil', 'Aimo', 'Aimore', 'AIX', 'al', 'ALA', 'Alai', 'Alamo', 'Alar', 'alary', 'alarm', 'alazor', 'Alf', 'ALFA', 'ALFE', 'Alfy', 'ALI', 'aly', 'Alia', 'Alie', 'alima', 'Alix', 'Aliza', 'ALM', 'Alma', 'alme', 'Almera', 'almery', 'Almyra', 'Almo', 'ALP', 'Alroy', 'AM', 'AMA', 'Amal', 'amala', 'Amalia', 'Amalie', 'Amar', 'Amara', 'Amaral', 'Amary', 'Amaryl', 'AME', 'Amer', 'Amery', 'Amero', 'AMI', 'Amy', 'Amia', 'Amie', 'Amye', 'Amil', 'amyl', 'amla', 'amli', 'Amo', 'Amoy', 'Amor', 'Amora', 'amoral', 'Amory', 'AMP', 'amper', 'Ampere', 'ampery', 'amply', 'Amr', 'amra', 'AO', 'AOA', 'AOP', 'aor', 'ar', 'ARA', 'Arae', 'Aram', 'Araxa', 'ARE', 'area', 'ary', 'aryl', 'Arly', 'ARM', 'Arma', 'armary', 'armer', 'army', 'Armil', 'armor', 'armory', 'ARO', 'aroma', 'aromal', 'aroxyl', 'ARP', 'arx', 'Ax', 'Axa', 'AXAF', 'axal', 'Axe', 'axer', 'axial', 'axil', 'AZ', 'Azal', 'Azalia', 'Azar', 'azo', 'Azof', 'azofy', 'Azor', 'Azral', 'E', 'EA', 'EAM', 'ear', 'Earl', 'Earla', 'Early', 'EAROM', 'Earp', 'EF', 'efl', 'EI', 'ey', 'EIA', 'eila', 'eimer', 'eyr', 'eyra', 'Eyre', 'eyry', 'EM', 'EMA', 'EMAIL', 'Emalia', 'eme', 'emer', 'Emera', 'Emery', 'EMF', 'EMI', 'emia', 'Emie', 'Emil', 'Emily', 'EML', 'Emory', 'EMP', 'empearl', 'empery', 'empory', 'EMR', 'EP', 'epi', 'epil', 'epimer', 'epimeral', 'epimere', 'Epizoa', 'EPROM', 'er', 'ERA', 'eral', 'ERE', 'EREP', 'ery', 'Eryx', 'ERL', 'Erma', 'Erme', 'Ermey', 'ERP', 'Ex', 'exla', 'exor', 'exp', 'EXPO', 'exr', 'Ez', 'Ezar', 'Ezara', 'Ezr', 'Ezra', 'F', 'FA', 'FAE', 'fala', 'falx', 'FAM', 'Fama', 'fame', 'Family', 'famp', 'FAO', 'FAX', 'faze', 'FE', 'FEA', 'feaze', 'Fey', 'FEM', 'FEMA', 'Feme', 'FEMF', 'Femi', 'femora', 'femoral', 'FEP', 'Fez', 'fy', 'FL', 'Fla', 'Flam', 'flame', 'flamer', 'flamy', 'flax', 'flaxy', 'fly', 'FM', 'FMEA', 'FMR', 'FO', 'foam', 'foamer', 'foamy', 'foamily', 'Foy', 'Fomor', 'fop', 'Fox', 'Foxe', 'foxer', 'foxery', 'foxy', 'foxie', 'foxily', 'foxly', 'fozy', 'FP', 'FPE', 'FPLA', 'FPM', 'FPO', 'FX', 'fz', 'i', 'y', 'ia', 'IAEA', 'ial', 'IAM', 'iao', 'ie', 'ye', 'yea', 'year', 'yeara', 'yearly', 'Iey', 'yep', 'yer', 'yere', 'Yermo', 'Yerxa', 'yex', 'yez', 'Yezo', 'Iy', 'Yi', 'Yila', 'Yim', 'iyo', 'yip', 'yipe', 'il', 'yl', 'ILA', 'Ilam', 'ilama', 'ILP', 'IM', 'ym', 'Ima', 'Yma', 'IMarE', 'Imer', 'IMF', 'imi', 'Imo', 'IMP', 'impearl', 'imper', 'impery', 'impf', 'impi', 'imply', 'implial', 'impofo', 'Imre', 'IO', 'yo', 'yoi', 'yoy', 'IOM', 'yom', 'yomer', 'IOP', 'yor', 'yore', 'yox', 'IP', 'IPE', 'IPL', 'IPM', 'IPO', 'ipomea', 'IPX', 'yr', 'IX', 'Ixia', 'Ixil', 'Ixora', 'Iz', 'Izar', 'ize', 'izer', 'Izy', 'L', 'LA', 'LaF', 'Laflam', 'Lafox', 'Lai', 'Laie', 'Lail', 'LAM', 'LAMA', 'Lamar', 'lame', 'lamer', 'Lamero', 'lamia', 'lamiae', 'Lamp', 'Lampe', 'lamper', 'lampf', 'lampfly', 'Lamprey', 'LAR', 'Lara', 'Laramie', 'lare', 'Laroy', 'LAX', 'laxer', 'laxly', 'Laz', 'Lazar', 'Lazare', 'lazary', 'lazarly', 'Lazaro', 'laze', 'Lazear', 'lazy', 'lazily', 'Lazio', 'Lazor', 'LF', 'LI', 'ly', 'Lia', 'Liam', 'Liao', 'Lie', 'Lil', 'Lila', 'Lily', 'LIM', 'lym', 'Lima', 'limail', 'lime', 'Lyme', 'limey', 'limer', 'limy', 'limli', 'limo', 'limp', 'limper', 'limpily', 'limply', 'lip', 'lipemia', 'lipoma', 'Lyra', 'Lyrae', 'lyre', 'Liz', 'Liza', 'lizary', 'lyze', 'LM', 'LME', 'LMF', 'LP', 'LPF', 'lpm', 'LPR', 'LR', 'lx', 'LXE', 'LZ', 'm', 'MA', 'MAE', 'Maera', 'MAF', 'Mafala', 'mafey', 'Mai', 'Maia', 'mail', 'MAL', 'Mala', 'Malar', 'Mali', 'Malia', 'malie', 'Mao', 'MAR', 'Mara', 'marae', 'maral', 'Marala', 'Mare', 'Mary', 'Maryl', 'Maryly', 'Marl', 'Marla', 'marly', 'Maro', 'Maroa', 'ME', 'MEA', 'mear', 'Meara', 'Mei', 'meio', 'MEP', 'mer', 'Mera', 'mere', 'Meryl', 'Merl', 'Merla', 'mero', 'merop', 'MERP', 'MF', 'MFA', 'MI', 'MY', 'MIA', 'miae', 'Mial', 'Miao', 'MIE', 'Myer', 'MIL', 'Mila', 'Mylar', 'Mio', 'Myo', 'myopia', 'MIP', 'Myra', 'ML', 'MLA', 'Mlar', 'MLF', 'Mli', 'MLR', 'mo', 'MOA', 'MOI', 'moy', 'Moia', 'moil', 'moio', 'Moyra', 'MOP', 'MOR', 'Mora', 'morae', 'Moraea', 'moral', 'more', 'Morea', 'Morey', 'Morly', 'Moro', 'MP', 'MPE', 'MPL', 'MPO', 'MPR', 'MR', 'MRA', 'MRE', 'MRP', 'o', 'OA', 'oaf', 'oam', 'oar', 'oary', 'OF', 'OFM', 'Ofo', 'oy', 'oie', 'oil', 'oily', 'oime', 'OM', 'oma', 'omao', 'Omar', 'ome', 'Omer', 'Omero', 'Omor', 'Omora', 'OMPF', 'Omro', 'OP', 'OPF', 'opia', 'OPM', 'OPX', 'or', 'Ora', 'orae', 'oral', 'Oram', 'Orazio', 'Ore', 'Orem', 'ory', 'Oryx', 'Oryza', 'orl', 'Orla', 'Orly', 'ORM', 'Orma', 'Orme', 'ormer', 'OROM', 'Oromo', 'orzo', 'Ox', 'oxea', 'oxer', 'oxfly', 'oxy', 'oxyl', 'oxyopia', 'Oxly', 'oxlip', 'oxo', 'Oz', 'Oza', 'P', 'PE', 'pea', 'peai', 'pear', 'Peary', 'Pearl', 'Pearla', 'pearly', 'PEI', 'peixere', 'peixerey', 'peize', 'PEM', 'PEP', 'Pepi', 'Per', 'Pera', 'Peraea', 'pere', 'perea', 'Perez', 'PERL', 'Perla', 'Perm', 'Pero', 'peroxy', 'peroxyl', 'perp', 'PEX', 'PF', 'Pfalz', 'pfx', 'PI', 'PIA', 'pial', 'piala', 'pie', 'piezo', 'pil', 'pily', 'pilm', 'pilmy', 'pim', 'Pima', 'pimp', 'pimpery', 'Pimpla', 'pimply', 'PIO', 'Pioxe', 'PIP', 'pipe', 'pipey', 'pix', 'pixy', 'pixie', 'pize', 'Pizor', 'PL', 'PLA', 'plaza', 'plf', 'pli', 'ply', 'Pliam', 'plie', 'plim', 'PLM', 'PLP', 'PLR', 'Plze', 'PM', 'PMA', 'PMO', 'PO', 'POA', 'POF', 'Pofo', 'poi', 'poy', 'poil', 'POM', 'pomary', 'pome', 'pomey', 'Pomeroy', 'Pomo', 'pomp', 'Pompea', 'Pompei', 'Pompey', 'Pompeia', 'POP', 'popie', 'POR', 'poral', 'pore', 'pory', 'poroma', 'pox', 'poxy', 'poz', 'PR', 'PRA', 'pram', 'prao', 'PRE', 'preamp', 'preaxial', 'prey', 'Prem', 'Premer', 'premia', 'premial', 'premie', 'premio', 'premoral', 'prep', 'prex', 'prexy', 'prez', 'Pry', 'PRO', 'proa', 'PROM', 'Prome', 'promo', 'promoral', 'prop', 'prox', 'proxy', 'prp', 'PX', 'R', 'RA', 'Rae', 'RAM', 'Rama', 'ramal', 'Rame', 'Ramey', 'Ramer', 'rami', 'ramie', 'Ramo', 'RAMP', 'ramper', 'RAO', 'rax', 'raze', 'razer', 'razor', 'RE', 'REA', 'ream', 'reamer', 'Reamy', 'Rey', 'REM', 'Rema', 'remail', 'REME', 'Remer', 'Remi', 'Remy', 'remop', 'remora', 'remore', 'Rempe', 'Rep', 'REX', 'Rexer', 'ry', 'Rye', 'ryme', 'RL', 'rly', 'RM', 'RMA', 'RMF', 'RMI', 'RMR', 'RO', 'ROA', 'roam', 'roamer', 'Roy', 'ROM', 'Roma', 'romal', 'Rome', 'romero', 'Romy', 'Romie', 'Romo', 'romp', 'romper', 'ROP', 'Rox', 'Roxi', 'Roxy', 'Roxie', 'Roz', 'Rozalie', 'Roze', 'Rozi', 'RP', 'RPM', 'RPO', 'RX', 'X', 'XA', 'Xe', 'XFE', 'xi', 'XIE', 'xyla', 'Xylia', 'Xipe', 'XL', 'XO', 'XOR', 'XP', 'xr', 'Z', 'ZA', 'zar', 'Zara', 'Zare', 'Zarla', 'zarp', 'Zea', 'Zep', 'zer', 'Zerla', 'zero', 'ZI', 'Zia', 'zila', 'ZIP', 'Zl', 'zo', 'zoa', 'Zoar', 'Zoara', 'Zoi', 'Zoie', 'Zoila', 'Zora', 'Zr', '']
    #validWds = scrableRegex(None, *sides, infiniteTiles=True, filename='words.txt')
    #correct = []
    if verbose:
        print("Done with tiles")
        print(validWds)
    heads = []
    for i in validWds:
        #heads.append(Node(i)))
        pass
    returning = []
    for e in heads:
        returning.append(e.findShortestPaths())
    return returning

if __name__ == '__main__':
    lines = ["abc", "def"]
    print(f"{scrableRegex('abc', 'a', 'b', 'c')=}")
    print(f"{scrableRegex('abc', 'abc', 'abc', 'abc', 'abc', 'a', 'abc', 'z', 'n')=}")
    print(f"{scrableRegex('def', 'd', 'l', 'z', 'k', 'm')=}")
    print(f"{scrableRegex('def', 'def', 'def', 'dep', 'zum')=}")

    print(f"{scrableRegex('abc', 'a', 'b', 'c', useall=True)=}")
    print(f"{scrableRegex('abc', 'abc', 'abc', 'abc', 'abc', useall=True)=}")
    print(f"{scrableRegex('def', 'd', 'e', 'f', 'z', useall=True)=}")
    print(f"{scrableRegex('def', 'def', 'def', 'def', useall=True)=}")

    #print(f"{scrableRegex('', 'YHU', 'ENR', 'AOB', 'LCT', fileVerbose=True, infiniteTiles=True, filename='words.txt')=}")
    print(f"{letterBoxed('AYP', 'LEO', 'RFI', 'MXZ', verbose=True)=}")