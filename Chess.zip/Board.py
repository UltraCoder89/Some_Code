from Piece import Piece
from Graphics import defaultColor
from Graphics import defaultBackground
from Graphics import blackBG
from Graphics import whiteBG
from copy import deepcopy

def getBoardString():
  strthing = ""
  for i in board:
    for slot in i:
      strthing += str((slot.piece + 1) * (slot.alligance + 1))
  return strthing


def getBoardCopy(y=-1, x=-1):
  try:
    if x + y == -2: return deepcopy(board)
    else: return deepcopy(board[y][x])
  except:
    print("Here")
    return Piece(-1, -1)


board = [
  [Piece(1, 1), Piece(2, 1), Piece(3, 1), Piece(4, 1), Piece(5, 1), Piece(3, 1), Piece(2, 1), Piece(1, 1)],
  [Piece(0, 1), Piece(0, 1), Piece(0, 1), Piece(0, 1), Piece(0, 1), Piece(0, 1), Piece(0, 1), Piece(0, 1)],
  [Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1)],
  [Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1)],
  [Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1)],
  [Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1), Piece(-1, -1)],
  [Piece(0, 0), Piece(0, 0), Piece(0, 0), Piece(0, 0), Piece(0, 0), Piece(0, 0), Piece(0, 0), Piece(0, 0)],
  [Piece(1, 0), Piece(2, 0), Piece(3, 0), Piece(4, 0), Piece(5, 0), Piece(3, 0), Piece(2, 0), Piece(1, 0)]
]

def cycle(pmove):
  for i in board:
    for slot in i:
      if slot.alligance != pmove:
        slot.enPassantCapture = False
  for x in range(8):
    for y in range(8):
      if y == 7 * pmove and board[y][x].piece == 0:
        board[y][x] = Piece(4, pmove)

remembered = []

def revertFakeMove():
  global remembered
  global board
  board = deepcopy(remembered)
  remembered = []

def promote(x, y, to):
  board[y][x] = Piece(to, board[y][x.alligance])

def fakeMove(mv):
  global remembered
  remembered = getBoardCopy()
  #print(mv)
  oldy = int(mv[0])
  oldx = int(mv[1])
  newy = int(mv[2])
  newx = int(mv[3])
  piece = board[oldy][oldx].piece
  nval = 0
  if piece == 0:
    try:
      if board[oldy][oldx + 1].enPassantCapture and newx == oldx + 1:
        board[newy][newx] = deepcopy(board[oldy][oldx])
        board[oldy][newx].blank()
        board[oldy][oldx].blank()
      else:
        nval += 1
    except: pass
    try:
      if board[oldy][oldx - 1].enPassantCapture and newx == oldx - 1:
        board[newy][newx] = deepcopy(board[oldy][oldx])
        board[oldy][newx].blank()
        board[oldy][oldx].blank()
      else:
        nval += 1
    except: pass
    if nval == 2:
      board[newy][newx] = deepcopy(board[oldy][oldx])
      board[oldy][oldx].blank()
  else:
    board[newy][newx] = deepcopy(board[oldy][oldx])
    board[oldy][oldx].blank()

def trueMove(mv):
  if len(mv) == 3:
    if mv[0] == 'B':
      board[0][2] = deepcopy(board[7][4])
      board[0][2].moved = True
      board[0][3] = deepcopy(board[7][0])
      board[0][4].blank()
      board[0][0].blank()
    else:
      board[7][2] = deepcopy(board[7][4])
      board[7][2].moved = True
      board[7][3] = deepcopy(board[7][0])
      board[7][4].blank()
      board[7][0].blank()
  elif len(mv) == 2:
    if mv[0] == 'B':
      board[0][6] = deepcopy(board[7][4])
      board[0][6].moved = True
      board[0][5] = deepcopy(board[7][7])
      board[0][7].blank()
      board[0][4].blank()
    else:
      board[7][6] = deepcopy(board[7][4])
      board[7][6].moved = True
      board[7][5] = deepcopy(board[7][7])
      board[7][7].blank()
      board[7][4].blank()
  else:
    oldy = int(mv[0])
    oldx = int(mv[1])
    newy = int(mv[2])
    newx = int(mv[3])
    piece = board[oldy][oldx].piece
    if piece == 0:
      try:
        if board[oldy][oldx + 1].enPassantCapture and newx == oldx + 1:
          print("Here")
          board[oldy][oldx + 1].blank()
      except: pass
      try:
        if board[oldy][oldx - 1].enPassantCapture and newx == oldx - 1:
          print("Here2")
          board[oldy][oldx - 1].blank()
      except: pass
    board[newy][newx] = deepcopy(board[oldy][oldx])
    if board[newy][newx].piece == 0 and board[newy][newx].moved == False and (newy == oldy + 2 or newy == oldy - 2): board[newy][newx].enPassantCapture = True
    board[newy][newx].moved = True
    board[oldy][oldx].blank()

def printBoard():
  switch = False
  print(defaultBackground, end="  ", sep="")
  print(defaultColor, end="")
  letters = "abcdefgh"
  counter = 1
  for i in letters: print(" ", i, end=" ", sep="")
  print()
  for i in board:
    switch = not switch
    print(defaultBackground, defaultColor, 9 - counter, sep = "", end = " ")
    counter += 1
    for slot in i:
      if switch:
        switch = False
        print(whiteBG, end="")
      else:
        switch = True
        print(blackBG, end="")
      slot.printSelf()
    print(defaultBackground, defaultColor, " ", 10 - counter, sep = "", end = "")
    print()
  print(defaultBackground, end="  ", sep="")
  print(defaultColor, end="")
  for i in letters: print(" ", i, end=" ", sep="")
  print(flush=True, end = "")