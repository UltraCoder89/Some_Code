from Board import printBoard
from Move import brain
from Move import cycle
Switch = 0
for i in range(1, 2000):
  printBoard()
  print()
  brain(Switch)
  cycle(Switch)
  if Switch == 1: Switch = 0
  else: Switch = 1
print("Game Excedes Limit")
#print("\n", getAllLegalMvs(1), sep="")  