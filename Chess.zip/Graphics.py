# black = "\033[38;5;87m" #Light Blue
#Bad Format:
# white = "\033[38;5;192m" #Yellow
# blackBG = "\u001b[48;5;196m" #Cherry Red
# whiteBG = "\u001b[48;5;20m" #Purple

#Actual Colors:
# black = "\033[38;5;237m"
# white = "\033[38;5;245m"
# blackBG = "\u001b[48;5;232m"
# whiteBG = "\u001b[48;5;7m"
# defaultColor = "\033[38;5;159m" #Blueish white

#Good Colors    
black = "\033[38;5;40m"
white = "\033[38;5;87m"
blackBG = "\u001b[48;5;6m"
whiteBG = "\u001b[48;5;238m"
defaultColor = "\033[38;5;159m" 

defaultBackground = "\u001b[40;5;0m"
#Ansi color codes
def printColors():
  for i in range(256): print(\033[38;5;nm + str(i) + "m", i, sep="", end="  ")