from random import randint
from Graphics import defaultBackground
from Graphics import defaultColor
from Board import getBoardCopy
from Board import trueMove
from Board import fakeMove
from Board import revertFakeMove
from Board import getBoardString
from Gamerules import Repetition as REPETITION 
from Board import printBoard
from Gamerules import moveRule as MVRULE 
from Board import cycle as cyc

memory = []

letters = {'a':0, 'b':1, 'c':2, 'd':3, 'e':4, 'f':5, 'g':6, 'h':7}
def trueNum(num): 
  try: 
    return 8 - int(num)
  except:
    return "ERR"
#1 -> 7 | 2 -> 6 | 3 -> 5 | 8-num

#These two functions are in my opinion some of the best examples of reusable code I have ever made
def validSquare(x, y, alligance):
  #-1 means do not even include this option and make the val false
  #1 means go on 
  #0 means include this option but set to false
  sptcpy = getBoardCopy(y, x) #sptcpy -> spot copy 
  if sptcpy.alligance == alligance:
    return -1
  elif sptcpy.alligance == -1:
    return 1
  else:
    return 0

def mvAppend(x, y, alligance):
  val = validSquare(x, y, alligance)
  vals = {-1:"", 1:(str(y) + str(x)), 0:(str(y) + str(x))}
  return vals[val]
  
def stayTrue(x, y, alligance):
  return validSquare(x, y, alligance) == 1

#Rook Moves Checked And Complete
def rookMoves(oldCordinates):
  oldy = int(oldCordinates[0])
  oldx = int(oldCordinates[1])
  alligance = getBoardCopy(oldy, oldx).alligance
  p1 = p2 = p3 = p4 = True
  mvs = []
  for magnitude in range(1, 8):
    if oldx + magnitude > 7: p1 = False
    if oldx - magnitude < 0: p2 = False
    if oldy + magnitude > 7: p3 = False
    if oldy - magnitude < 0: p4 = False
    if p1:
      mvs.append(mvAppend((oldx + magnitude), oldy, alligance))
      p1 = stayTrue((oldx + magnitude), oldy, alligance)
    if p2:
      mvs.append(mvAppend((oldx - magnitude), oldy, alligance))
      p2 = stayTrue((oldx - magnitude), oldy, alligance)
    if p3:
      mvs.append(mvAppend(oldx, (oldy + magnitude), alligance))
      p3 = stayTrue(oldx, (oldy + magnitude), alligance)
    if p4:
      mvs.append(mvAppend(oldx, (oldy - magnitude), alligance))
      p4 = stayTrue(oldx, (oldy - magnitude), alligance)
  return mvs

#Knight Moves Checked And Complete
def knightMoves(oldCordinates):
  oldy = int(oldCordinates[0])
  oldx = int(oldCordinates[1])
  alligance = getBoardCopy(oldy, oldx).alligance
  mvs = []
  if oldy + 2 < 8 and oldx + 1 < 8: mvs.append(mvAppend(oldx + 1, oldy + 2, alligance))
  if oldy - 2 > -1 and oldx + 1 < 8: mvs.append(mvAppend(oldx + 1, oldy -2, alligance))
  if oldy + 2 < 8 and oldx - 1 > -1: mvs.append(mvAppend(oldx - 1, oldy + 2, alligance))
  if oldy - 2 > -1 and oldx - 1 > -1: mvs.append(mvAppend(oldx - 1, oldy -2, alligance))

  if oldy + 1 < 8 and oldx + 2 < 8: mvs.append(mvAppend(oldx + 2, oldy + 1, alligance))
  if oldy - 1 > -1 and oldx + 2 < 8: mvs.append(mvAppend(oldx + 2, oldy - 1, alligance))
  if oldy + 1 < 8 and oldx - 2 > -1: mvs.append(mvAppend(oldx - 2, oldy + 1, alligance))
  if oldy - 1 > -1 and oldx - 2 > -1: mvs.append(mvAppend(oldx - 2, oldy - 1, alligance))
  return mvs

#Bishop Moves Checked And Complete
def bishopMoves(oldCordinates):
  oldy = int(oldCordinates[0])
  oldx = int(oldCordinates[1])
  alligance = getBoardCopy(oldy, oldx).alligance
  p1 = p2 = p3 = p4 = True
  mvs = []
  for magnitude in range(1, 8):
    if oldy + magnitude > 7: p1 = p2 = False
    if oldy - magnitude < 0: p3 = p4 = False
    if oldx + magnitude > 7: p1 = p3 = False
    if oldx - magnitude < 0: p2 = p4 = False
    if p1:
      mvs.append(mvAppend(oldx + magnitude, oldy + magnitude, alligance))
      p1 = stayTrue(oldx + magnitude, oldy + magnitude, alligance)
    if p2:
      mvs.append(mvAppend(oldx - magnitude, oldy + magnitude, alligance))
      p2 = stayTrue(oldx - magnitude, oldy + magnitude, alligance)
    if p3:
      mvs.append(mvAppend(oldx + magnitude, oldy - magnitude, alligance))
      p3 = stayTrue(oldx + magnitude, oldy - magnitude, alligance)
    if p4:
      mvs.append(mvAppend(oldx - magnitude, oldy - magnitude, alligance))
      p4 = stayTrue(oldx - magnitude, oldy - magnitude, alligance)
  return mvs

#Queen Moves Are Functioning as Long As Rook And Bishop Moves Are
def queenMoves(oldCordinates):
  return bishopMoves(oldCordinates) + rookMoves(oldCordinates)

#King Moves Checked And Complete
def kingMoves(oldCordinates):
  oldy = int(oldCordinates[0])
  oldx = int(oldCordinates[1])
  alligance = getBoardCopy(oldy, oldx).alligance
  mvs = []
  for x in range(-1, 2):
    for y in range(-1, 2):
      if not (x == 0 and y == 0):
        if oldx + x < 8 and oldx + x > -1 and oldy + y < 8 and oldy + y > -1:
          mvs.append(mvAppend(oldx + x, oldy + y, alligance))
        else:
          continue
  return mvs

#Works
def pmvAppend(x, y, alligance):
  val = validSquare(x, y, alligance)
  vals = {-1:"", 1:"", 0:(str(y) + str(x))}
  return vals[val]

def pmvAppend2(x, y, alligance):
  val = validSquare(x, y, alligance)
  vals = {-1:"", 1:(str(y) + str(x)), 0:""}
  return vals[val]

#Enpassant must be checked
def pawnMoves(oldCordinates):
  oldy = int(oldCordinates[0])
  oldx = int(oldCordinates[1])
  alligance = getBoardCopy(oldy, oldx).alligance
  mvs = []
  if alligance == 0:
    if not getBoardCopy(oldy, oldx).moved and stayTrue(oldx, oldy - 1, alligance): 
      mvs.append(pmvAppend2(oldx, oldy - 2, alligance))
    mvs.append(pmvAppend2(oldx, oldy - 1, alligance))
    if oldx + 1 < 8 and oldy - 1 > -1: mvs.append(pmvAppend(oldx + 1, oldy - 1, alligance))
    if oldx - 1 > -1 and oldy - 1 > -1: mvs.append(pmvAppend(oldx - 1, oldy - 1, alligance))
    if oldx - 1 > -1 and getBoardCopy(oldy, oldx - 1).enPassantCapture: mvs.append(mvAppend(oldx - 1, oldy - 1, alligance))
    if oldx + 1 < 8 and getBoardCopy(oldy, oldx + 1).enPassantCapture: mvs.append(mvAppend(oldx + 1, oldy - 1, alligance))

  if alligance == 1:
    if not getBoardCopy(oldy, oldx).moved and stayTrue(oldx, oldy + 1, alligance): 
      mvs.append(pmvAppend2(oldx, oldy + 2, alligance))
    mvs.append(pmvAppend2(oldx, oldy + 1, alligance))
    if oldx + 1 < 8 and oldy + 1 < 8: mvs.append(pmvAppend(oldx + 1, oldy + 1, alligance))
    if oldx - 1 > -1 and oldy + 1 < 8: mvs.append(pmvAppend(oldx - 1, oldy + 1, alligance))
    if oldx - 1 > -1 and getBoardCopy(oldy, oldx - 1).enPassantCapture: mvs.append(mvAppend(oldx - 1, oldy + 1, alligance))
    if oldx + 1 < 8 and getBoardCopy(oldy, oldx + 1).enPassantCapture: mvs.append(mvAppend(oldx + 1, oldy + 1, alligance))
  return mvs

#Working
def getMoves(x, y):
  pieceType = int(getBoardCopy(y, x).piece)
  ocs = str(y) + str(x)
  if pieceType == 0:
    return pawnMoves(ocs)
  elif pieceType == 1:
    return rookMoves(ocs)
  elif pieceType == 2:
    return knightMoves(ocs)
  elif pieceType == 3:
    return bishopMoves(ocs)
  elif pieceType == 4:
    return queenMoves(ocs)
  elif pieceType == 5:
    return kingMoves(ocs)

#Working
def getAllAttacking(Alligance):
  cpy = getBoardCopy()
  attacking = []
  for y in range(8):
    for x in range(8):
      if cpy[y][x].alligance != -1 and cpy[y][x].alligance != Alligance: attacking.append(getMoves(x, y))
  return attacking

#Working
def squareAttackedQuery(x, y):
  alligance = getBoardCopy(y, x).alligance
  return str(y) + str(x) in str(getAllAttacking(alligance))

#Check
def inCheck(alligance):
  cpy = getBoardCopy()
  for y in range(8):
    for x in range(8):
      if cpy[y][x].piece == 5 and cpy[y][x].alligance == alligance:
        return squareAttackedQuery(x, y)

def queenSideCastleQuery(alligance):
  if alligance == 0:
    attacks = str(getAllAttacking(0))
    if (not ("72" in attacks or "73" in attacks or "74" in attacks)) and getBoardCopy(7, 0).moved == False and getBoardCopy(7, 4).moved == False and getBoardCopy(7, 1).alligance == -1 and getBoardCopy(7, 2).alligance == -1 and getBoardCopy(7, 3).alligance == -1: return True
  elif alligance == 1:
    attacks = str(getAllAttacking(1))
    if (not ("02" in attacks or "03" in attacks or "04" in attacks)) and getBoardCopy(0, 0).moved == False and getBoardCopy(0, 4).moved == False and getBoardCopy(0, 1).alligance == -1 and getBoardCopy(0, 2).alligance == -1 and getBoardCopy(0, 3).alligance == -1: return True
  return False
    
def kingSideCastleQuery(alligance):
  if alligance == 0:
    attacks = str(getAllAttacking(0))
    if (not ("74" in attacks or "75" in attacks or "76" in attacks)) and getBoardCopy(7, 4).moved == False and getBoardCopy(7, 7).moved == False and getBoardCopy(7, 5).alligance == -1 and getBoardCopy(7, 6).alligance == -1: return True
  elif alligance == 1:
    attacks = str(getAllAttacking(1))
    if (not ("04" in attacks or "05" in attacks or "06" in attacks)) and getBoardCopy(0, 4).moved == False and getBoardCopy(0, 7).moved == False and getBoardCopy(0, 5).alligance == -1 and getBoardCopy(0, 6).alligance == -1: return True
  return False

#legal move checkers

def mvLegal(Move):
  if len(Move) != 4:
    return False
  oldCordinates = Move[:2]
  oldy = int(oldCordinates[0])
  oldx = int(oldCordinates[1])
  alligance = getBoardCopy(oldy, oldx).alligance
  fakeMove(Move)
  val = inCheck(alligance)
  revertFakeMove()
  return not val

def mvVeryLegal(Move):
  #print(Move)
  #print(Move[2:] in str(getMoves(int(Move[1]), int(Move[0]))))
  return mvLegal(Move) and Move[2:] in str(getMoves(int(Move[1]), int(Move[0])))


def getAllLegalMvs(Alligance):
  semiLegalMoves = []
  for x in range(8):
    for y in range(8):
      if getBoardCopy(y, x).alligance == Alligance:
        for i in getMoves(x, y):
          semiLegalMoves.append(str(y) + str(x) + str(i))
  legalMoves = []
  for i in filter(mvLegal, semiLegalMoves): legalMoves.append(i)
  return legalMoves

def stalemate1(pmove):
  thing = [1, 0]
  val = len(getAllLegalMvs(thing[pmove])) == 0
  if val:
    print("Draw by Stalemate")
  return val

def stalemate2():
  if len(memory) >= MVRULE:
    print("Draw by 50 move rule")
  return len(memory) >= MVRULE

def stalemate3():
  memory.append(getBoardString())
  if str(memory).count(getBoardString()) >= REPETITION:
    print("Draw By Repetition")
  return str(memory).count(getBoardString()) >= REPETITION

def stalemate(pmove):
  return stalemate1(pmove) or stalemate2() or stalemate3()

def checkmate():
  if inCheck(1):
    if len(getAllLegalMvs(1)) == 0:
      printBoard()
      print(defaultBackground, defaultColor, "Victory to Player White")
      exit("Victory to Player White")
  else:
    if len(getAllLegalMvs(0)) == 0:
      printBoard()
      print(defaultBackground, defaultColor, "Victory to Player Black")
      exit("Victory To Player Black")

def cycle(pMove):
  cyc(pMove)
  if inCheck(1) or inCheck(0):
    checkmate()
  else:
    if stalemate(pMove):
      printBoard()
      print(defaultColor, "Draw to Player Black & White", sep="")
      exit(0)

def clearMem(mv):
  oldy = int(mv[0])
  oldx = int(mv[1])
  newy = int(mv[2])
  newx = int(mv[3])
  if getBoardCopy(oldy, oldx).piece == 0 or getBoardCopy(newy, newx).piece != -1:
    memory.clear()

auto = [True, True]

def brain(playerMove):
  print(defaultColor, end="")
  """
  Cyclonic complexity threashold was breached because I don't feel like simplifying my code, thank you.
  """
  if auto[playerMove]:
    #letter = {0:'a', 1:'b', 2:'c', 3:'d', 4:'e', 5:'f', 6:'g', 7:'h'}
    mvs = getAllLegalMvs(playerMove)
    spam = randint(0, len(mvs) - 1)
    #print(8 - int(mvs[spam][0]), letter[int(mvs[spam][1])], 8 - int(mvs[spam][2]), letter[int(mvs[spam][3])], sep="")
    clearMem(mvs[spam])
    trueMove(mvs[spam])
    return None
  print(defaultBackground, defaultColor, "Input Move, For Details On How To Do So Type \"help\"\t", sep="", end="")
  userInput = input().lower()
  if "l" in userInput.lower():
    print("For a move type the letter and number location of a piece IE e2 and then the place you would like to move that piece IE e4.\nFor castling, if is is queenside castles, type 0-0-0, else if it kingside castles, type 0-0", flush=True)
    return brain(playerMove)
  elif len(userInput) == 4:
    try:
      parsedUI = str(trueNum(int(userInput[1]))) + str(letters[userInput[0]]) + str(int(trueNum(userInput[3]))) + str(letters[userInput[2]])
      if len(parsedUI) != 4:
        print("Non Legal Move")
        return brain(playerMove)
      if getBoardCopy(int(parsedUI[0]), int(parsedUI[1])).alligance == playerMove and getBoardCopy(int(parsedUI[0]), int(parsedUI[1])).alligance != -1 and mvVeryLegal(parsedUI):
        clearMem(parsedUI)
        trueMove(parsedUI)
        return None
    except: pass
  elif len(userInput) == 5:
    if userInput == "admin":
      print("Normal Mvs?", getAllLegalMvs(playerMove))
      print("Queen Side?", queenSideCastleQuery(playerMove))
      print("King Side?", kingSideCastleQuery(playerMove))
      print("Variable \"playerMove\"", playerMove)
      return brain(playerMove)
    elif queenSideCastleQuery(playerMove):
      a = ["WWW", "BBB"]
      trueMove(a[playerMove])
      return None
  elif len(userInput) == 3:
    if kingSideCastleQuery(playerMove):
      a = ["WW", "BB"]
      trueMove(a[playerMove])
      return None
  elif userInput.lower() == 'r':
    auto[playerMove] = True
    return brain(playerMove)
  print("Invalid Input, Please Try Again")
  return brain(playerMove)