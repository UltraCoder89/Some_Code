Repetition = 3
moveRule = 50