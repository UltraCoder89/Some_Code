from Graphics import white
from Graphics import black

class Piece():
  def __init__(self, piece, alligance):
    self.moved = False
    self.enPassantCapture = False
    self.piece = piece
    self.alligance = alligance
  def printSelf(self):
    pics = {0:"♙", 1:"♜", 2:"♞", 3:"♝", 4:"♛", 5:"♚", -1:" "}
    print(black if self.alligance == 1 else white, end="")
    print(" ", pics[self.piece], end = " ", sep="")
  def blank(self):
    self.piece = -1
    self.alligance = -1



"""
piece
0 = pawn
1 = rook
2 = knight
3 = bishop
4 = queen
5 = king
||||||||||
alligance
0 = white
1 = black
"""